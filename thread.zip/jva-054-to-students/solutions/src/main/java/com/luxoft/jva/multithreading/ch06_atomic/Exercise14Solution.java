package com.luxoft.jva.multithreading.ch06_atomic;

import static java.lang.System.out;

/**
 * EXTRA!
 *
 * In this exercise we will play ping-pong again but this time we will implement whole stuff using synchronization.
 *
 * @author BKuczynski.
 */
public class Exercise14Solution {
	public static final int GAME_LENGTH = 10;

	public static void main(String[] args) {
		Ball ball = new Ball();
		final Thread pongThread = new Thread(new Pong(ball));
		final Thread pingThread = new Thread(new Ping(ball));
		pongThread.setName("pong-thread");
		pingThread.setName("ping-thread");
		pongThread.start();
		pingThread.start();

		final long start = System.nanoTime();

		try {
			pingThread.join();
			pongThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		final long duration = System.nanoTime() - start;

		out.printf("duration %,d (ns)%n", duration);
		out.printf("%,d ns/op%n", duration / (GAME_LENGTH * 2L));
		out.printf("%,d ops/s%n", (GAME_LENGTH * 2L * 1_000_000_000L) / duration);
		out.println("pingValue = " + ball.ping + ", pongValue = " + ball.pong);
	}

	static class Ball {
		private int ping = -1;
		private int pong = -1;

		public int getPing() {
			return ping;
		}

		public synchronized void setPing(int ping) {
			this.ping = ping;
		}

		public int getPong() {
			return pong;
		}

		public synchronized void setPong(int pong) {
			this.pong = pong;
		}
	}

	static class Ping implements Runnable {

		private final Ball ball;

		Ping(Ball ball) {
			this.ball = ball;
		}

		@Override
		public void run() {
			for (int i = 0; i < GAME_LENGTH; i++) {
				ball.setPing(i);
				while (i != ball.getPong()) {
				}
			}
		}
	}

	static class Pong implements Runnable {

		private final Ball ball;

		Pong(Ball ball) {
			this.ball = ball;
		}

		@Override
		public void run() {
			for (int i = 0; i < GAME_LENGTH; i++) {
				while (ball.getPing() != i) {
				}
				ball.setPong(i);
			}
		}
	}


}

