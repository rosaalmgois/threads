package com.luxoft.jva.multithreading.ch07_collections_and_queues;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static java.lang.System.out;

/**
 * In this exercise we will play with {@link Collections#synchronizedList(List)} methods and compare them with {@link CopyOnWriteArrayList}.
 * <ul>
 * <li>Create instance of {@link List} and fill it.</li>
 * <li>Create class {@link Printer} that implements {@link Runnable} and will remove values to list.</li>
 * <li>Create class {@link Clerk} that implements {@link Runnable} and will add values to list.</li>
 * <li>Run this classes and observe results</li>
 * </ul>
 *
 * @author BKuczynski.
 */
public class Exercise15Solution {

	private static final int JOB_TODO = 1_000;

	private static Thread printer;

	public static void main(String[] args) {
		List<Integer> jobs = new ArrayList<>();
//		List<Integer> jobs = Collections.synchronizedList(new ArrayList<>());
//		List<Integer> jobs = new CopyOnWriteArrayList<>();
		printer = new Thread(new Printer(jobs));
		Thread clerk = new Thread(new Clerk(jobs));

		long start = System.nanoTime();

		printer.start();
		clerk.start();

		try {
			printer.join();
			clerk.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		final long duration = System.nanoTime() - start;
		out.printf("duration %,d (ns)%n", duration);
		out.printf("jobs %,d (ns)%n", jobs.size());

	}

	static void finishhim() {
		printer.interrupt();
	}

	static class Printer implements Runnable {

		private final List<Integer> jobs;

		Printer(List<Integer> jobs) {
			this.jobs = jobs;
		}

		@Override
		public void run() {
			while (true) {
				if (jobs.size() > 0)
					jobs.remove(0);
				if (Thread.currentThread().isInterrupted() && jobs.size() == 0)
					return;
			}
		}
	}

	static class Clerk implements Runnable {

		private final List<Integer> jobs;

		Clerk(List<Integer> jobs) {
			this.jobs = jobs;
		}

		@Override
		public void run() {
			for (int i = 0; i < JOB_TODO; i++)
				jobs.add(i);

			finishhim();
		}
	}
}
