package com.luxoft.jva.multithreading.ch03_priorities;

import com.luxoft.jva.multithreading.utils.PrimeValidator;

import java.time.LocalDateTime;
import java.util.stream.IntStream;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class that extends {@link Thread}.</li>
 * <li>Create few new instance of our class.</li>
 * <li>Set them demon flag.</li>
 * <li>And run them.</li>
 * <li>DO NOT call {@link Thread#join()}.</li>
 * </ul>
 * <p>
 * Class should make some time-consuming job and log start and end time.
 * You could use {@link PrimeValidator} to validate first 10k numbers.
 *
 * @author BKuczynski.
 */
public class Exercise8Solution {

	public static void main(String[] args) {
		IntStream.rangeClosed(1, 10).mapToObj(i -> {
			Thread t = new Thread(new PrimeGenerator(10000));
			t.setDaemon(true);
			return t;
		}).forEach(Thread::start);
	}

}
