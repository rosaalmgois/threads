package com.luxoft.jva.multithreading.ch04_synchronization;

import java.time.LocalDateTime;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class {@link Cinema} that:
 * <ul>
 * <li>Has two fields that represents number of free seats at two halls with some initial value.</li>
 * <li>Has two fields that represents mutexes.</li>
 * <li>Methods for sell and return tickets.</li>
 * <li>Those methods should be synchronized via mutexes</li>
 * </ul>
 * </li>
 * <li>Create classes {@link TicketOffice1} and {@link TicketOffice2}
 * <ul>
 * <li>Both implements {@link Runnable}</li>
 * <li>Both has reference to {@link Cinema}</li>
 * <li>In {@link Runnable#run()} method put some sequence of selling and returning tickets.</li>
 * </ul>
 * </li>
 * </ul>
 *
 * @author BKuczynski.
 */
public class Exercise10Solution {

	public static void main(String[] args) {
		Cinema cinema = new Cinema();
		Thread to1 = new Thread(new TicketOffice1(cinema), "Ticket Office 1");
		Thread to2 = new Thread(new TicketOffice2(cinema), "Ticket Office 2");

		to1.start();
		to2.start();

		try{
			to1.join();
			to2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(cinema);
	}

}

class Cinema {

	private Object mutexRoom1 = new Object();
	private Object mutexRoom2 = new Object();

	private int seatRoom1 = 20;
	private int seatRoom2 = 20;

	public boolean sell1(int number) {
		synchronized (mutexRoom1) {
			if (number < seatRoom1) {
				seatRoom1 -= number;
				return true;
			}
			return false;
		}
	}

	public boolean sell2(int number) {
		synchronized (mutexRoom2) {
			if (number < seatRoom2) {
				seatRoom2 -= number;
				return true;
			}
			return false;
		}
	}

	public boolean return1(int number) {
		synchronized (mutexRoom1) {
			seatRoom1 += number;
			return true;
		}
	}

	public boolean return2(int number) {
		synchronized (mutexRoom2) {
			seatRoom2 += number;
			return true;

		}
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer("Cinema{");
		sb.append("seatRoom1=").append(seatRoom1);
		sb.append(", seatRoom2=").append(seatRoom2);
		sb.append('}');
		return sb.toString();
	}
}

class TicketOffice1 implements Runnable {

	private final Cinema cinema;

	TicketOffice1(Cinema cinema) {
		this.cinema = cinema;
	}

	@Override
	public void run() {
		cinema.sell1(3);
		cinema.sell1(2);
		cinema.sell2(2);
		cinema.return1(3);
		cinema.sell1(5);
		cinema.sell2(2);
		cinema.sell2(2);
		cinema.sell2(2);
	}
}

class TicketOffice2 implements Runnable {

	private final Cinema cinema;

	TicketOffice2(Cinema cinema) {
		this.cinema = cinema;
	}

	@Override
	public void run() {
		cinema.sell2(2);
		cinema.sell2(4);
		cinema.sell1(2);
		cinema.sell1(1);
		cinema.return2(2);
		cinema.sell1(3);
		cinema.sell2(2);
		cinema.sell1(2);
	}
}