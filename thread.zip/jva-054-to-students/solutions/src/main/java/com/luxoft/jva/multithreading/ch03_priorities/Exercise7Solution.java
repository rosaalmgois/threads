package com.luxoft.jva.multithreading.ch03_priorities;

import com.luxoft.jva.multithreading.utils.PrimeValidator;
import com.luxoft.jva.multithreading.utils.ThreadInfoPrinter;

import java.time.LocalDateTime;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class that extends {@link Thread}.</li>
 * <li>Create few new instance of our class.</li>
 * <li>Set them different priorities.</li>
 * <li>And run them.</li>
 * <li>Wait to all threads using {@link Thread#join()}.</li>
 * </ul>
 * <p>
 * Class should make some time-consuming job and log start and end time.
 * You could use {@link PrimeValidator} to validate first 10k numbers.
 *
 * @author BKuczynski.
 */
public class Exercise7Solution {

	public static void main(String[] args) {
		IntStream.rangeClosed(1, 10).mapToObj(i -> {
			Thread t = new Thread(new PrimeGenerator(10000));
			t.setPriority(i);
			return t;
		}).forEach(Thread::start);
	}

}

class PrimeGenerator implements Runnable {

	private static final ThreadInfoPrinter pr = new ThreadInfoPrinter();

	private final PrimeValidator validator;
	private final long max;

	public PrimeGenerator(long max) {
		this.validator = new PrimeValidator();
		this.max = max;
	}

	@Override
	public void run() {
		long number = 1l;
		while (number < max) {
			if (validator.isPrime(number)) {
				pr.print(Thread.currentThread());
				System.out.printf("Number %d is prime!\n", number);
			}
			number++;
		}
	}
}
