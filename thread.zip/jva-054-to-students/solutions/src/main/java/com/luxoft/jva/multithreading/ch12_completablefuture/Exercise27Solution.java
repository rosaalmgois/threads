package com.luxoft.jva.multithreading.ch12_completablefuture;

/**
 * Created by BKuczynski on 2016-11-02.
 */
public class Exercise27Solution {
}
