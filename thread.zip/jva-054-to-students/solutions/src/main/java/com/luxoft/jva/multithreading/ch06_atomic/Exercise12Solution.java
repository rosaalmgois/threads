package com.luxoft.jva.multithreading.ch06_atomic;

import static java.lang.System.out;

/**
 * In this exercise we will play volatile ping-pong:
 * <ul>
 * <li>Create classes {@link Pong} and {@link Pong} that implements {@link Runnable}.</li>
 * <li>Create class {@link Ball} that has two volatile fields ping and pong.</li>
 * </ul>
 * <p>
 * <p>
 * In loop
 * {@link Pong}:
 * <ul>
 * <li>Increase ping value by 1</li>
 * <li>Do nothing while current step != pong</li>
 * </ul>
 * <p>
 * <p>
 * {@link Pong}:
 * <ul>
 * <li>Do nothing while ping != current step</li>
 * <li>Increase pong value by 1</li>
 * </ul>
 * <p>
 * Make all classes above as static.
 *
 * @author BKuczynski.
 */
public class Exercise12Solution {

	public static final int GAME_LENGTH = 10_000_000;

	public static void main(String[] args) {
		Ball ball = new Ball();
		final Thread pongThread = new Thread(new Pong(ball));
		final Thread pingThread = new Thread(new Ping(ball));
		pongThread.setName("pong-thread");
		pingThread.setName("ping-thread");
		pongThread.start();
		pingThread.start();

		final long start = System.nanoTime();

		try {
			pingThread.join();
			pongThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		final long duration = System.nanoTime() - start;

		out.printf("duration %,d (ns)%n", duration);
		out.printf("%,d ns/op%n", duration / (GAME_LENGTH * 2L));
		out.printf("%,d ops/s%n", (GAME_LENGTH * 2L * 1_000_000_000L) / duration);
		out.println("pingValue = " + ball.ping + ", pongValue = " + ball.pong);
	}

	static class Ball {
		public volatile int ping = -1;
		public volatile int pong = -1;
	}

	static class Ping implements Runnable {

		private final Ball ball;

		Ping(Ball ball) {
			this.ball = ball;
		}

		@Override
		public void run() {
			for (int i = 0; i < GAME_LENGTH; i++) {
				ball.ping = i;
				while (i != ball.pong) {
				}
			}
		}
	}

	static class Pong implements Runnable {

		private final Ball ball;

		Pong(Ball ball) {
			this.ball = ball;
		}

		@Override
		public void run() {
			for (int i = 0; i < GAME_LENGTH; i++) {
				while (ball.ping != i) {
				}
				ball.pong = i;
			}
		}
	}

}


