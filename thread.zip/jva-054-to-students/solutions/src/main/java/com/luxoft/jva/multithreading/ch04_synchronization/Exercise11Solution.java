package com.luxoft.jva.multithreading.ch04_synchronization;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class {@link PostOffice} that:
 * <ul>
 * <li>Has a {@link Collection} of @{link Mail}s.</li>
 * <li>Collection has maximum size of 10.</li>
 * <li>Has methods {@link PostOffice#accept} and {@link PostOffice#spend} that takes mail and return mail.</li>
 * <li>Method {@link PostOffice#accept} will wait if collection has maximum size.</li>
 * <li>Method {@link PostOffice#spend} will wait if collection is empty.</li>
 * </ul>
 * </li>
 * <li>Create class {@link Postman} that implements {@link Runnable} and has reference to {@link PostOffice}
 * <ul>
 * <li>Postman will takes messages from post office.</li>
 * </ul>
 * </li>
 * <li>Create class {@link LogisticCenter} that implements {@link Runnable} and has reference to {@link PostOffice}
 * <ul>
 * <li>Logistic center will send messages from post office.</li>
 * </ul>
 * </li>
 * <li>Setup post office, logistic center and postman then run it.</li>
 * </ul>
 * <p>
 * Questions:
 * <ul>
 * <li>How you will synchronize methods in PostOffice?</li>
 * <li>What will happen if you increase number of postmen?</li>
 * <li>What will happen if you increase number of logistic centers?</li>
 * </ul>
 *
 * @author BKuczynski.
 */
public class Exercise11Solution {

	public static void main(String[] args) {
		PostOffice postOffice = new PostOffice();
		Thread lc = new Thread(new LogisticCenter(postOffice));
		Thread pm = new Thread(new Postman(postOffice));

		lc.start();
		pm.start();

		try {
			lc.join();
			pm.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("OK");
	}

}

class Mail {

	private final LocalDateTime createdAt;

	Mail() {
		createdAt = LocalDateTime.now();
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer("Mail{");
		sb.append("createdAt=").append(createdAt);
		sb.append('}');
		return sb.toString();
	}
}


class PostOffice {

	private static final int MAX_SIZE = 10;

	private LinkedList<Mail> storage = new LinkedList<>();

	public synchronized void accept(Mail mail) {
		while (storage.size() == MAX_SIZE) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		storage.offer(mail);
		System.out.printf("You have mail %s\n", mail);
		notifyAll();
	}

	public synchronized Mail spend() {
		while (storage.size() == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		Mail mail = storage.poll();
		notifyAll();
		return mail;
	}
}

class LogisticCenter implements Runnable {

	private final PostOffice postOffice;

	LogisticCenter(PostOffice postOffice) {
		this.postOffice = postOffice;
	}

	@Override
	public void run() {
		Stream.generate(Mail::new).limit(100).forEach(postOffice::accept);
	}
}

class Postman implements Runnable {

	private final PostOffice postOffice;

	Postman(PostOffice postOffice) {
		this.postOffice = postOffice;
	}

	@Override
	public void run() {
		Stream.generate(postOffice::spend).limit(100).forEach(m -> {
			System.out.printf("I will provide %s\n", m);
			try {
				TimeUnit.MILLISECONDS.sleep(10L);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		});
	}
}
