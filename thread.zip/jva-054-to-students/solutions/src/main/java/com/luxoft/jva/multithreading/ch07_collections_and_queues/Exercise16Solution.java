package com.luxoft.jva.multithreading.ch07_collections_and_queues;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

/**
 * In this exercise we will play with {@link BlockingQueue} by implementing producer-consumer pattern.
 * <p>
 * <ul>
 * <li>Producer – puts objects to queue with some small delay</li>
 * <li>Consumer – gets objects from queue without delay.</li>
 * <li>Queue – is a communication chanel between producer and consumer.</li>
 * </ul>
 *
 * @author BKuczynski.
 */
public class Exercise16Solution {

	private static final int PROBLEM_LENGTH = 1_000;


	public static void main(String[] args) {
		BlockingQueue<Integer> queue = new LinkedBlockingDeque<>(); // ArrayBlockingQueue
		Thread producer = new Thread(new Producer(queue));
		Thread consumer = new Thread(new Consumer(queue));

		consumer.start();
		producer.start();

		try{
			consumer.join();
			producer.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	static class Producer implements Runnable {

		private final BlockingQueue<Integer> queue;

		Producer(BlockingQueue<Integer> queue) {
			this.queue = queue;
		}

		@Override
		public void run() {
			for (int i = 0; i < PROBLEM_LENGTH; i++) {
				queue.add(i);
				try {
					TimeUnit.MILLISECONDS.sleep(100L);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	static class Consumer implements Runnable {

		private final BlockingQueue<Integer> queue;

		Consumer(BlockingQueue<Integer> queue) {
			this.queue = queue;
		}

		@Override
		public void run() {
			for (int i = 0; i < PROBLEM_LENGTH; i++) {
				try {
					Integer taken = queue.take();
					System.out.printf("Taken %d %n", taken);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}
	}

}
