package com.luxoft.jva.multithreading.ch01_creating;

import java.util.concurrent.ThreadFactory;
import java.util.stream.Stream;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class {@link SimpleThreadFactory} that implements {@link ThreadFactory}.</li>
 * <li>Create new instance of our class.</li>
 * <li>Run it and observe results</li>
 * </ul>
 * <p>
 * Class {@link SimpleThreadFactory} should create instances of {@link SimpleRunnable} from {@link Exercise1Solution}
 * or {@link SimpleThread} from {@link Exercise2Solution}.
 *
 * @author BKuczynski.
 */
public class Exercise3Solution {

	public static void main(String[] args) {
		ThreadFactory factory = new SimpleThreadFactory();
		Stream.generate(SimpleRunnable::new).limit(4).map(factory::newThread).forEach(Thread::start);
	}

}

class SimpleThreadFactory implements ThreadFactory {
	@Override
	public Thread newThread(Runnable r) {
		return new Thread(r);
	}
}