package com.luxoft.jva.multithreading.ch02_interrupting;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create two classes that extends {@link Thread}.</li>
 * <li>First class will sleep for 5 seconds, second for 7 seconds .</li>
 * <li>Create new instance of our classes and start them.</li>
 * <li>Call {@link Thread#join()} on them.</li>
 * </ul>
 * <p>
 * Remove call to join and rerun program.
 *
 * @author BKuczynski.
 */
public class Exercise6Solution {

	public static void main(String[] args) {
		System.out.printf("We started at %s\n", LocalDateTime.now());
		Thread lazySmurf1 = new Thread(new LazySmurf(5));
		Thread lazySmurf2 = new Thread(new LazySmurf(7));

		lazySmurf1.start();
		lazySmurf2.start();

		try {
			lazySmurf1.join();
			lazySmurf2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.printf("We finished at %s\n", LocalDateTime.now());
	}

}

class LazySmurf implements Runnable {

	private final int sleepTime;

	LazySmurf(int sleepTime) {
		this.sleepTime = sleepTime;
	}

	@Override
	public void run() {
		try {
			TimeUnit.SECONDS.sleep(sleepTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}