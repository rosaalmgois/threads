package com.luxoft.jva.multithreading.ch02_interrupting;

import com.luxoft.jva.multithreading.utils.PrimeValidator;

import java.util.concurrent.TimeUnit;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class {@link PrimeGenerator} that extends {@link Thread} and use {@link PrimeValidator}.</li>
 * <li>Create new instance of our class and start them.</li>
 * <li>Sleep main thread for few seconds and then call {@link Thread#interrupt()} on our task</li>
 * </ul>
 * <p>
 * <p>
 * Class {@link PrimeGenerator} should:
 * <ul>
 * <li>Takes long number (start from 1) and pass it to {@link PrimeValidator}.</li>
 * <li>After validator finish should check is thread interrupted.
 * <ul>
 * <li>If it's <samp>true</samp> finish by <samp>return</samp>.</li>
 * <li>Otherwise takes next number.</li>
 * </ul>
 * </li>
 * </ul>
 * <p>
 * After run of this code change {@link PrimeGenerator} to finish by throwing {@link InterruptedException}
 *
 * @author BKuczynski.
 */
public class Exercise4Solution {

	public static void main(String[] args) {
		Thread primeGeneratorThread = new Thread(new PrimeGenerator());
		primeGeneratorThread.start();
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		primeGeneratorThread.interrupt();
	}

}

class PrimeGenerator implements Runnable {

	private final PrimeValidator validator;

	public PrimeGenerator() {
		this.validator = new PrimeValidator();
	}

	@Override
	public void run() {
		long number = 1l;
		while (true) {
			if (validator.isPrime(number))
				System.out.printf("Number %d is prime!\n", number);
			if (Thread.currentThread().isInterrupted()) {
				System.out.printf("The Prime Generator has been Interrupted\n");
				return;
			}
			number++;
		}
	}
}
