package com.luxoft.jva.multithreading.ch01_creating;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class {@link SimpleRunnable} that implements {@link Runnable}.</li>
 * <li>Create new {@link Thread} that takes instance of our class.</li>
 * <li>Run this thread and observe results</li>
 * </ul>
 * <p>
 * Class {@link SimpleRunnable} should print us some basic information about thread.
 * Use {@link Thread#getName()} and {@link Thread#getId()}.
 *
 * @author BKuczynski.
 */
public class Exercise1Solution {

	public static void main(String[] args) {
		Thread simple = new Thread(new SimpleRunnable());
		simple.start();
	}

}

class SimpleRunnable implements Runnable {

	@Override
	public void run() {
		System.out.printf("My name is %s. My ID is %s and state is %s\n", Thread.currentThread().getName(), Thread.currentThread().getId(), Thread.currentThread().getState());
	}
}