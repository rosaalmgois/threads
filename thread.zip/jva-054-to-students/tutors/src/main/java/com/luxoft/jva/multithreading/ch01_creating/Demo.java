package com.luxoft.jva.multithreading.ch01_creating;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class Demo
{



    public static void main(String[] args) throws ExecutionException, InterruptedException
    {
        ExecutorService service = Executors.newFixedThreadPool(10);

        Future<String> nameF = service.submit(() -> Thread.currentThread().getName());

        nameF.cancel(true);


    }
}
