package com.luxoft.jva.multithreading.ch14_exceptionhandling;

/**
 * Created by BKuczynski on 2016-11-07.
 */
public class ExceptionHandlerTutor
{

    public static void main(String[] args)
    {
        Thread.UncaughtExceptionHandler handler = (t, e) -> System.out.printf("Thread %s throws %s%n", t.getName(), e);
        Thread.setDefaultUncaughtExceptionHandler(handler);
        Runnable task = () ->
        {
            throw new RuntimeException("You shall not pass");
        };
        new Thread(task, "Gandalf").start();
    }
}
