package com.luxoft.jva.multithreading.ch01_creating;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class ThreadFactoryDemo
{
    public static void main(String[] args)
    {
        ThreadFactory simpleFactory = (r) -> new Thread(r);

        ThreadFactory factory = Executors.defaultThreadFactory();


    }
}
