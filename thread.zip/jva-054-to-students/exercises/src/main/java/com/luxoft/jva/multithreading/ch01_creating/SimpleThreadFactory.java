package com.luxoft.jva.multithreading.ch01_creating;

import java.util.concurrent.ThreadFactory;

/**
 * Created by slt-ptc-9 on 11/7/2018.
 */
public class SimpleThreadFactory implements ThreadFactory{
    private static SimpleThreadFactory instance = new SimpleThreadFactory();

    private SimpleThreadFactory(){}

    @Override
    public Thread newThread(Runnable r) {
        return new Thread(r);
    }

    public static SimpleThreadFactory getInstance(){
        return instance;
    }
}
