package com.luxoft.jva.multithreading.ch03_priorities;

import com.luxoft.jva.multithreading.ch02_interrupting.PrimeGenerator;
import com.luxoft.jva.multithreading.utils.PrimeValidator;

import java.time.LocalDateTime;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class that extends {@link Thread}.</li>
 * <li>Create few new instance of our class.</li>
 * <li>Set them different priorities.</li>
 * <li>And run them.</li>
 * <li>Wait to all threads using {@link Thread#join()}.</li>
 * </ul>
 * <p>
 * Class should make some time-consuming job and log start and end time. You
 * could use {@link PrimeValidator} to validate first 10k numbers.
 *
 * @author BKuczynski.
 */
public class Exercise7 {

	public static void main(String[] args) throws InterruptedException {
		System.out.printf("We started at %s\n", LocalDateTime.now());
		long[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33, 10l, 25, 20, 3310l, 25, 20,
				3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 3310l, 25, 20, 33,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 33, 10l, 25, 20, 3310l, 25, 20, };
		Thread t1 = new MYPrimeGenerator("T1",numbers);
		Thread t2 = new MYPrimeGenerator("T2",numbers);
		Thread t3 = new MYPrimeGenerator("T3",numbers);
		Thread t4 = new MYPrimeGenerator("T4",numbers);
		Thread t5 = new MYPrimeGenerator("T5",numbers);
		
		t1.setPriority(1);
		t2.setPriority(2);
		t3.setPriority(1);
		t4.setPriority(2);
		t5.setPriority(5);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		
		t1.join();
		t2.join();
		t3.join();
		t4.join();
		t5.join();
		
		System.out.printf("We finished at %s\n", LocalDateTime.now());
	}

	static class MYPrimeGenerator extends  Thread {

	    private final long[] numbers;
	    private PrimeValidator primeValidator = new PrimeValidator();
		private String name;

	    public MYPrimeGenerator(String name, long[] numbers){
	        this.numbers = numbers;
	        this.name = name;
	    }
	    
	    @Override
	    public void run() {
	        for (int i = 0; i < numbers.length; i++) {
	            long number = numbers[i];
	            boolean prime = primeValidator.isPrime(number);
	            if(prime) {
	            	System.out.println(name+":     Number valid" + number);	
	            }
	            
	            if (isInterrupted()){
	                System.out.println("is Interrupted!!");
	                return;
	            }
	        }
	    }
	}
	
	static class MyTask implements Runnable {

		@Override
		public void run() {
			String aux = "";
			for (int i = 0; i < 1000; i++) {
				aux = aux.concat("" + i);
				System.out.print(aux);
			}

		}
	}

}
