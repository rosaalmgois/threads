package com.luxoft.jva.multithreading.ch03_priorities;

import com.luxoft.jva.multithreading.utils.PrimeValidator;

public class MYPrimeGenerator  extends  Thread {

	private long lenght;
	private PrimeValidator primeValidator = new PrimeValidator();
	private String name;

	public MYPrimeGenerator(String name, long lenght){
        this.lenght = lenght;
        this.name = name;
        setDaemon(false);
    }
    
    @Override
    public void run() {
        for (int i = 0; i < lenght; i++) {
            boolean prime = primeValidator.isPrime(i);
            if(prime) {
            	System.out.println(name+":     Number valid" + i);	
            }
            
            if (isInterrupted()){
                System.out.println("is Interrupted!!");
                return;
            }
        }
        
        System.out.println(name+ " finish");
    }
	
	
}