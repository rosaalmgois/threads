package com.luxoft.jva.multithreading.ch01_creating;

/**
 * Created by slt-ptc-9 on 11/7/2018.
 */
class SimpleThread extends   Thread{
    @Override
    public void run() {
        System.out.println("Here i am");
    }
}