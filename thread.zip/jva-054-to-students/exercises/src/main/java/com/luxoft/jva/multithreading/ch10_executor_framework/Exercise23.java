package com.luxoft.jva.multithreading.ch10_executor_framework;

import com.luxoft.jva.multithreading.ch08_locks_and_semaphores.Exercise17;

import java.util.concurrent.ExecutorService;

/**
 * Let's back to {@link Exercise17} and reimplement Printer to {@link ExecutorService}.
 *
 * @author BKuczynski.
 */
public class Exercise23 {

	public static void main(String[] args) {
		// your code goes here
	}

}
