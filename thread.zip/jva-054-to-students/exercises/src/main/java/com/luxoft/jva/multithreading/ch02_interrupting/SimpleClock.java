package com.luxoft.jva.multithreading.ch02_interrupting;

/**
 * Created by slt-ptc-9 on 11/7/2018.
 */
public class SimpleClock extends  Thread {

    private Integer number = 1;

    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                System.out.print(number++);
                sleep(2000);
            } catch (InterruptedException e) {
                System.out.println("");
                System.out.println("Intererupted!");
                return;
            }
        }

    }
}
