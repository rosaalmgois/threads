package com.luxoft.jva.multithreading.ch02_interrupting;

import java.time.LocalDateTime;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create two classes that extends {@link Thread}.</li>
 * <li>First class will sleep for 5 seconds, second for 7 seconds .</li>
 * <li>Create new instance of our classes and start them.</li>
 * <li>Call {@link Thread#join()} on them.</li>
 * </ul>
 * <p>
 *
 * @author BKuczynski.
 */
public class Exercise6 {

	public static void main(String[] args) throws InterruptedException {
		System.out.printf("We started at %s\n", LocalDateTime.now());
		// your code goes here
		Thread t1 = new T1();
		Thread t2 = new T2();

		t1.start();
		t2.start();;

		t1.join();
		t2.join();

		System.out.printf("We finished at %s\n", LocalDateTime.now());
	}


	static class T1 extends    Thread{
		@Override
		public void run() {
			try {
				System.out.println("T1 start");
				sleep(5000);
				System.out.println("T1 finish");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	static class T2 extends    Thread{
		@Override
		public void run() {
			try {
				System.out.println("T2 start");
				sleep(7000);
				System.out.println("T2 finish");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
