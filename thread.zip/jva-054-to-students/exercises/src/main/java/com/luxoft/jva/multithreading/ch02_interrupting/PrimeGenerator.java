package com.luxoft.jva.multithreading.ch02_interrupting;

import com.luxoft.jva.multithreading.utils.PrimeValidator;

/**
 * Created by slt-ptc-9 on 11/7/2018.
 */
public class PrimeGenerator extends  Thread {

    private final long[] numbers;
    private PrimeValidator primeValidator = new PrimeValidator();

    public PrimeGenerator(long[] numbers){
        this.numbers = numbers;
    }
    @Override
    public void run() {
        for (int i = 0; i < numbers.length; i++) {
            long number = numbers[i];
            boolean prime = primeValidator.isPrime(number);
            System.out.println("Number" + number+ " valid? "+ prime);
            if (isInterrupted()){
                System.out.println("is Interrupted!!");
                return;
            }
        }
    }
}
