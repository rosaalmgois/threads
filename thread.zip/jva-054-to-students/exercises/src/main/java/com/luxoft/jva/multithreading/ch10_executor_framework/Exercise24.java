package com.luxoft.jva.multithreading.ch10_executor_framework;

import java.util.concurrent.ScheduledExecutorService;

/**
 * In this exercise we will implement system announcing departures. We will create time table that will be contains scheduled task.
 *
 * There will be {@link Megaphone} class, that has {@link ScheduledExecutorService} to announce departure.
 *
 * @author BKuczynski.
 */
public class Exercise24 {

	public static void main(String[] args) {

	}

}
