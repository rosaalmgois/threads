package com.luxoft.jva.multithreading.ch13_threadlocal;

/**
 * Created by BKuczynski on 2016-11-02.
 */
public class Exercise28 {
}
