package com.luxoft.jva.multithreading.ch06_atomic;

/**
 * EXTRA!
 *
 * In this exercise we will play ping-pong again but this time we will implement whole stuff using synchronization.
 *
 * @author BKuczynski.
 */
public class Exercise14 {

	public static void main(String[] args) {
		// your code goes here
	}

}

