package com.luxoft.jva.multithreading.ship;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 * https://gist.github.com/oyushche/ce0861bc4b117bd9a1c6305bdcfb8c7a
 */
public class StargateOneShip extends JPanel {
    public static final int EDGE = 400;
    private final int GATE_OPEN_Y = 200;
    private final int GATE_CLOSED_Y = 90;

    private int shipX = 50;
    private int shipY = 130;

    private int gateX = 300;
    private int gateY = 90;

    Object waiter = new Object();

    private void run() throws InterruptedException {
        Thread gate = new Thread(new Gate());


        while (shipX < 250) {
            move();
        }
        gate.start();
        synchronized (waiter) {
            waiter.wait();
        }
        while (true) {
            move();
        }

    }

    private void move() throws InterruptedException {
        shipX += 1;
        System.out.println("shipX " + shipX);
        repaint();
        Thread.sleep(30);

        if(shipX > 300){
            shipX = 0;
        }
    }


    public static void main(String[] args) throws InterruptedException {
        JFrame frame = new JFrame("StargateOneShip");
        frame.setSize(new Dimension(400, 400));
        frame.setLocation(150, 150);

        StargateOneShip stargate = new StargateOneShip();

        frame.add(stargate);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setVisible(true);

        stargate.run();
    }

    private void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            // ignore
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        g.setColor(Color.BLUE);
        g.fillRect(shipX, shipY, 20, 20);

        g.setColor(Color.BLACK);
        g.fillRect(300, 0, 15, 90);
        g.fillRect(300, 200, 15, 200);


        g.setColor(Color.RED);
        g.fillRect(gateX, gateY, 15, 110);
    }

    class Ship extends Thread {
        @Override
        public void run() {
            while (true) {
                shipX += 1;
                System.out.println("shipX " + shipX);
                repaint();
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    class Gate implements Runnable {

        @Override
        public void run() {

            if (shipX < 250) {
                try {
                    synchronized (waiter) {
                        waiter.wait();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            while (gateY < GATE_OPEN_Y) {
                gateY += 1;
                repaint();
                sleep(30);
            }

            synchronized (waiter) {
                waiter.notifyAll();
                System.out.println("notifyAll ");
            }

            sleep(2000);
            close();
        }
    }

    private void close() {
        while (gateY > GATE_CLOSED_Y) {
            gateY -= 1;
            repaint();
            sleep(30);
        }
    }


}
