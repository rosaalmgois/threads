package com.luxoft.jva.multithreading.ch03_priorities;

import com.luxoft.jva.multithreading.utils.PrimeValidator;

import java.time.LocalDateTime;

/**
 * In this exercise we will:
 * <ul>
 * <li>Create class that extends {@link Thread}.</li>
 * <li>Create few new instance of our class.</li>
 * <li>Set them demon flag.</li>
 * <li>And run them.</li>
 * <li>DO NOT call {@link Thread#join()}.</li>
 * </ul>
 * <p>
 * Class should make some time-consuming job and log start and end time.
 * You could use {@link PrimeValidator} to validate first 10k numbers.
 *
 * @author BKuczynski.
 */
public class Exercise8 {

	public static void main(String[] args) throws InterruptedException {
		System.out.printf("We started at %s\n", LocalDateTime.now());
		MYPrimeGenerator t1 = new MYPrimeGenerator("T1",10000);
		MYPrimeGenerator t2 = new MYPrimeGenerator("T2",10000);
		
		t1.start();
		t2.start();
		
		System.out.printf("We finished at %s\n", LocalDateTime.now());
	}
}
